"use client";

import Image from "next/image";
import Link from "next/link";
import { createContext, useContext, useEffect, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import {
  ArrowRight,
  BadgeCheck,
  BarChart3,
  Bot,
  Brush,
  Code2,
  Compass,
  Instagram,
  Languages,
  Megaphone,
  MessageCircle,
  Moon,
  PenTool,
  Quote,
  Send,
  Sparkles,
  Sun,
  Target,
  TrendingUp
} from "lucide-react";
import { motion, useScroll, useTransform } from "framer-motion";
import { portfolioSections, process, projects, services, testimonials } from "@/lib/portfolio-data";

const iconMap = {
  identity: PenTool,
  design: Brush,
  web: Code2,
  strategy: Compass,
  ads: Megaphone
};

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0 }
};

type Language = "en" | "fr";
type ThemeMode = "dark" | "light";

const siteCopy = {
  en: {
    nav: { about: "About", services: "Services", portfolio: "Portfolio", contact: "Contact", start: "Start" },
    heroBadge: "Digital Marketing & AI Strategy Freelancer",
    heroCopy:
      "I help ambitious brands look sharper, communicate smarter, and grow faster with premium design, conversion-focused websites, advertising, and AI-powered strategy.",
    viewCaseStudies: "View case studies",
    aboutLabel: "About Me",
    aboutTitle: "I am Taha Yassine Moussaoui, the strategist behind TYMarketing.",
    aboutP1:
      "TYMarketing brings together premium visual design, performance marketing, website development, and practical AI strategy for founders, local businesses, and service brands.",
    aboutP2:
      "The work is built to feel refined, but also useful: clear offers, better content systems, stronger campaign assets, and websites that make the next step obvious.",
    stats: [
      ["24", "PDF portfolio pages extracted"],
      ["78", "Visual assets organized"],
      ["06", "Case studies generated"],
      ["02", "Languages supported"]
    ],
    servicesTitle: "Services",
    servicesCopy: "Everything a modern brand needs to look premium and move with precision.",
    portfolioTitle: "Portfolio Projects",
    portfolioCopy: "Case-study cards generated from the PDF portfolio and organized into website-ready sections.",
    sectionsLabel: "PDF Portfolio Sections",
    sectionsTitle: "Extracted services, images, and placeholders from the PDF.",
    testimonialsTitle: "Testimonials",
    testimonialsCopy: "Trusted by founders who want design taste, strategic clarity, and clean execution.",
    processTitle: "Process",
    processCopy: "A focused workflow from brand clarity to campaign optimization.",
    contactTitle: "Ready to build a brand that looks premium and performs?",
    contactCopy:
      "Tell me what you are building, where the brand is now, and what kind of result you want from the next 30 to 90 days.",
    contactForm: {
      name: "Name",
      email: "Email",
      project: "Project type",
      message: "Message",
      namePlaceholder: "Your name",
      emailPlaceholder: "you@example.com",
      projectPlaceholder: "Brand, website, ads...",
      messagePlaceholder: "Tell me about your goals, timeline, and current brand.",
      submit: "Send request",
      success: "Thanks. Your message is ready to send by email."
    },
    caseStudy: "Case Study",
    challenge: "Challenge",
    solution: "Solution",
    visuals: "Visuals",
    visualsCopy: "Extracted PDF images used as the project gallery.",
    placeholder: "Placeholder",
    footerHome: "Home"
  },
  fr: {
    nav: { about: "A propos", services: "Services", portfolio: "Portfolio", contact: "Contact", start: "Demarrer" },
    heroBadge: "Freelance Digital Marketing & Strategie IA",
    heroCopy:
      "J'aide les marques ambitieuses a paraitre plus premium, communiquer plus clairement et croitre plus vite avec le design, les sites web, la publicite et la strategie IA.",
    viewCaseStudies: "Voir les projets",
    aboutLabel: "A propos",
    aboutTitle: "Je suis Taha Yassine Moussaoui, le stratege derriere TYMarketing.",
    aboutP1:
      "TYMarketing combine design premium, marketing de performance, developpement web et strategie IA pratique pour les fondateurs, entreprises locales et marques de services.",
    aboutP2:
      "Chaque projet est pense pour etre elegant et utile: offres claires, meilleurs systemes de contenu, supports de campagne solides et sites web orientes conversion.",
    stats: [
      ["24", "Pages PDF extraites"],
      ["78", "Visuels organises"],
      ["06", "Etudes de cas creees"],
      ["02", "Langues disponibles"]
    ],
    servicesTitle: "Services",
    servicesCopy: "Tout ce qu'une marque moderne doit avoir pour paraitre premium et avancer avec precision.",
    portfolioTitle: "Projets Portfolio",
    portfolioCopy: "Etudes de cas generees depuis le PDF et organisees pour le web.",
    sectionsLabel: "Sections du PDF",
    sectionsTitle: "Services, images et placeholders extraits du PDF.",
    testimonialsTitle: "Temoignages",
    testimonialsCopy: "Pour les fondateurs qui veulent du gout, de la clarte strategique et une execution propre.",
    processTitle: "Processus",
    processCopy: "Un workflow clair, de la strategie de marque a l'optimisation des campagnes.",
    contactTitle: "Pret a construire une marque premium et performante ?",
    contactCopy:
      "Expliquez votre projet, l'etat actuel de votre marque et le resultat souhaite sur les 30 a 90 prochains jours.",
    contactForm: {
      name: "Nom",
      email: "Email",
      project: "Type de projet",
      message: "Message",
      namePlaceholder: "Votre nom",
      emailPlaceholder: "vous@example.com",
      projectPlaceholder: "Marque, site web, publicite...",
      messagePlaceholder: "Parlez-moi de vos objectifs, delais et de votre marque actuelle.",
      submit: "Envoyer la demande",
      success: "Merci. Votre message est pret a etre envoye par email."
    },
    caseStudy: "Etude de cas",
    challenge: "Defi",
    solution: "Solution",
    visuals: "Visuels",
    visualsCopy: "Images extraites du PDF utilisees comme galerie du projet.",
    placeholder: "Placeholder",
    footerHome: "Accueil"
  }
};

const SitePrefsContext = createContext<{
  language: Language;
  theme: ThemeMode;
  setLanguage: (language: Language) => void;
  setTheme: (theme: ThemeMode) => void;
} | null>(null);

function useSitePrefs() {
  const context = useContext(SitePrefsContext);
  if (!context) {
    throw new Error("useSitePrefs must be used inside PageShell");
  }
  return context;
}

function useCopy() {
  const { language } = useSitePrefs();
  return siteCopy[language];
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <motion.p
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-80px" }}
      variants={fadeUp}
      transition={{ duration: 0.6 }}
      className="mb-4 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.22em] text-brand-green"
    >
      <Sparkles className="h-4 w-4" />
      {children}
    </motion.p>
  );
}

export function SectionTitle({ title, copy, dark = false }: { title: string; copy: string; dark?: boolean }) {
  return (
    <div className="mx-auto max-w-3xl text-center">
      <SectionLabel>{title}</SectionLabel>
      <motion.h2
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-80px" }}
        variants={fadeUp}
        transition={{ duration: 0.65, delay: 0.05 }}
        className={`text-balance text-3xl font-semibold leading-tight sm:text-5xl ${
          dark ? "text-brand-ink" : "text-white"
        }`}
      >
        {copy}
      </motion.h2>
    </div>
  );
}

export function Header() {
  const { language, setLanguage, theme, setTheme } = useSitePrefs();
  const copy = siteCopy[language];
  const links = [
    [copy.nav.about, "/about"],
    [copy.nav.services, "/services"],
    [copy.nav.portfolio, "/portfolio"],
    [copy.nav.contact, "/contact"]
  ];

  return (
    <header className="fixed left-0 right-0 top-0 z-40 px-4 py-4">
      <nav className="mx-auto flex max-w-7xl items-center justify-between rounded-full border border-white/10 bg-black/[0.45] px-4 py-3 shadow-premium backdrop-blur-md sm:px-6">
        <Link href="/" className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-full bg-brand-green text-sm font-black text-brand-dark">
            TY
          </span>
          <span className="hidden text-sm font-semibold tracking-wide text-white sm:block">TYMarketing</span>
        </Link>
        <div className="hidden items-center gap-6 text-sm text-white/70 md:flex">
          {links.map(([label, href]) => (
            <Link key={href} href={href} className="transition hover:text-white">
              {label}
            </Link>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            aria-label="Toggle dark mode"
            className="grid h-10 w-10 place-items-center rounded-full border border-white/10 bg-white/[0.08] text-white transition hover:border-brand-green hover:text-brand-green"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
          <button
            type="button"
            onClick={() => setLanguage(language === "en" ? "fr" : "en")}
            aria-label="Toggle language"
            className="inline-flex h-10 items-center gap-1 rounded-full border border-white/10 bg-white/[0.08] px-2 text-xs font-semibold text-white transition hover:border-brand-green hover:text-brand-green sm:gap-2 sm:px-3"
          >
            <Languages className="h-4 w-4" />
            {language.toUpperCase()}
          </button>
          <Link
            href="/contact"
            className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-brand-ink transition hover:bg-brand-green hover:text-brand-dark"
          >
            {copy.nav.start} <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </nav>
    </header>
  );
}

export function Footer() {
  const copy = useCopy();

  return (
    <footer className="bg-black px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto flex max-w-7xl flex-col gap-5 border-t border-white/10 pt-8 text-sm text-white/50 sm:flex-row sm:items-center sm:justify-between">
        <p>&copy; 2026 TYMarketing. Taha Yassine Moussaoui.</p>
        <div className="flex gap-5">
          <Link href="/" className="transition hover:text-brand-green">{copy.footerHome}</Link>
          <Link href="/services" className="transition hover:text-brand-green">{copy.nav.services}</Link>
          <Link href="/contact" className="transition hover:text-brand-green">{copy.nav.contact}</Link>
        </div>
      </div>
    </footer>
  );
}

export function PageShell({ children }: { children: ReactNode }) {
  const { scrollYProgress } = useScroll();
  const [language, setLanguage] = useState<Language>("en");
  const [theme, setTheme] = useState<ThemeMode>("dark");

  useEffect(() => {
    const savedLanguage = window.localStorage.getItem("tymarketing-language") as Language | null;
    const savedTheme = window.localStorage.getItem("tymarketing-theme") as ThemeMode | null;
    if (savedLanguage === "en" || savedLanguage === "fr") setLanguage(savedLanguage);
    if (savedTheme === "dark" || savedTheme === "light") setTheme(savedTheme);
  }, []);

  useEffect(() => {
    window.localStorage.setItem("tymarketing-language", language);
    window.localStorage.setItem("tymarketing-theme", theme);
    document.documentElement.lang = language;
  }, [language, theme]);

  return (
    <SitePrefsContext.Provider value={{ language, theme, setLanguage, setTheme }}>
      <main className={`overflow-hidden bg-brand-ink ${theme === "light" ? "theme-light" : "theme-dark"}`}>
        <motion.div
          style={{ scaleX: scrollYProgress }}
          className="fixed left-0 top-0 z-50 h-1 w-full origin-left bg-brand-green"
        />
        <Header />
        {children}
        <FloatingActions />
        <Footer />
      </main>
    </SitePrefsContext.Provider>
  );
}

export function InnerHero({ eyebrow, title, copy, image }: { eyebrow: string; title: string; copy: string; image?: string }) {
  return (
    <section className="noise-layer grid-bg relative bg-brand-ink px-4 pb-20 pt-36 sm:px-6 lg:px-8">
      <div className="absolute inset-x-0 top-0 h-72 bg-[radial-gradient(circle_at_50%_0%,rgba(0,191,99,0.30),transparent_56%)]" />
      <div className="relative mx-auto grid max-w-7xl items-center gap-10 lg:grid-cols-[1fr_0.8fr]">
        <div>
          <SectionLabel>{eyebrow}</SectionLabel>
          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-balance text-5xl font-semibold leading-[0.95] text-white sm:text-7xl"
          >
            {title}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="mt-7 max-w-2xl text-lg leading-8 text-white/70 sm:text-xl"
          >
            {copy}
          </motion.p>
        </div>
        {image ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.75, delay: 0.15 }}
            className="relative h-[360px] overflow-hidden rounded-[28px] border border-white/10 shadow-premium"
          >
            <Image src={image} alt={`${title} visual`} fill priority sizes="(min-width: 1024px) 40vw, 100vw" className="object-cover" />
          </motion.div>
        ) : (
          <div className="relative hidden h-[360px] rounded-[28px] border border-white/10 bg-brand-dark lg:block" />
        )}
      </div>
    </section>
  );
}

export function HomePage() {
  return (
    <PageShell>
      <HomeContent />
    </PageShell>
  );
}

function HomeContent() {
  const { scrollYProgress } = useScroll();
  const heroY = useTransform(scrollYProgress, [0, 0.32], [0, -120]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.26], [1, 0.28]);

  const copy = useCopy();

  return (
    <>
      <section className="noise-layer grid-bg relative min-h-screen bg-brand-ink px-4 pb-16 pt-32 sm:px-6 lg:px-8">
        <div className="absolute inset-x-0 top-0 h-72 bg-[radial-gradient(circle_at_50%_0%,rgba(0,191,99,0.30),transparent_56%)]" />
        <motion.div
          style={{ y: heroY, opacity: heroOpacity }}
          className="relative mx-auto grid max-w-7xl items-center gap-12 lg:min-h-[calc(100vh-8rem)] lg:grid-cols-[1.02fr_0.98fr]"
        >
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="mb-8 inline-flex items-center gap-2 rounded-full border border-white/[0.12] bg-white/5 px-4 py-2 text-sm text-white/75 backdrop-blur"
            >
              <BadgeCheck className="h-4 w-4 text-brand-green" />
              {copy.heroBadge}
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.75, delay: 0.1 }}
              className="text-balance text-5xl font-semibold leading-[0.95] text-white sm:text-7xl lg:text-8xl"
            >
              TYMarketing
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.75, delay: 0.2 }}
              className="mt-7 max-w-2xl text-lg leading-8 text-white/70 sm:text-xl"
            >
              {copy.heroCopy}
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.75, delay: 0.3 }}
              className="mt-10 flex flex-col gap-4 sm:flex-row"
            >
              <Link href="/portfolio" className="inline-flex items-center justify-center gap-2 rounded-full bg-brand-green px-6 py-4 font-semibold text-brand-dark transition hover:bg-white">
                {copy.viewCaseStudies} <ArrowRight className="h-5 w-5" />
              </Link>
              <a href="https://www.instagram.com/tymarketing.ma/" target="_blank" rel="noreferrer" className="inline-flex items-center justify-center rounded-full border border-white/[0.14] px-6 py-4 font-semibold text-white transition hover:border-brand-green hover:text-brand-green">
                Instagram
              </a>
            </motion.div>
          </div>
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 24 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.85, delay: 0.25 }}
            className="relative"
          >
            <div className="absolute -inset-6 rounded-[36px] bg-brand-green/20 blur-3xl" />
            <Image src="/tymarketing-visual.svg" alt="TYMarketing brand strategy dashboard visual" width={1200} height={900} priority className="relative w-full rounded-[32px] border border-white/10 shadow-premium" />
          </motion.div>
        </motion.div>
        <div className="relative mx-auto mt-8 max-w-7xl overflow-hidden border-y border-white/10 py-5">
          <div className="marquee flex w-[200%] gap-8 whitespace-nowrap text-sm font-semibold uppercase tracking-[0.2em] text-white/50">
            {Array.from({ length: 2 }).map((_, group) => (
              <div key={group} className="flex min-w-[50%] gap-8">
                {["Brand Identity", "Graphic Design", "Websites", "AI Strategy", "Advertising", "Growth"].map((item) => (
                  <span key={`${group}-${item}`}>{item}</span>
                ))}
              </div>
            ))}
          </div>
        </div>
      </section>
      <AboutSection />
      <StatsSection />
      <ServicesSection />
      <PortfolioSection />
      <TestimonialsSection />
      <ProcessSection />
      <ContactSection />
    </>
  );
}

export function AboutSection() {
  const copy = useCopy();

  return (
    <section className="bg-white px-4 py-24 text-brand-ink sm:px-6 lg:px-8">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.8fr_1.2fr]">
        <div>
          <SectionLabel>{copy.aboutLabel}</SectionLabel>
          <motion.h2 initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }} variants={fadeUp} transition={{ duration: 0.65 }} className="text-balance text-4xl font-semibold leading-tight sm:text-6xl">
            {copy.aboutTitle}
          </motion.h2>
        </div>
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }} variants={fadeUp} transition={{ duration: 0.65, delay: 0.1 }} className="grid gap-6 text-lg leading-8 text-black/[0.65]">
          <p>{copy.aboutP1}</p>
          <p>{copy.aboutP2}</p>
          <div className="grid gap-4 sm:grid-cols-3">
            {[["AI", "Strategy-led workflows"], ["360", "Brand to launch execution"], ["01", "Focused freelance partner"]].map(([stat, label]) => (
              <div key={stat} className="border-t border-black/10 pt-5">
                <p className="text-4xl font-semibold text-brand-dark">{stat}</p>
                <p className="mt-2 text-sm font-medium text-black/[0.55]">{label}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export function StatsSection() {
  const copy = useCopy();

  return (
    <section className="bg-brand-ink px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto grid max-w-7xl gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {copy.stats.map(([value, label], index) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, delay: index * 0.07 }}
            className="rounded-lg border border-white/10 bg-white/[0.04] p-7"
          >
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.15 + index * 0.07 }}
              className="text-5xl font-semibold text-brand-green"
            >
              {value}
            </motion.p>
            <p className="mt-4 text-sm font-medium text-white/[0.62]">{label}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

export function ServicesSection() {
  const copy = useCopy();

  return (
    <section className="bg-brand-dark px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionTitle title={copy.servicesTitle} copy={copy.servicesCopy} />
        <div className="mt-14 grid gap-4 md:grid-cols-2 lg:grid-cols-5">
          {services.map((service, index) => {
            const Icon = iconMap[service.icon];
            return (
              <motion.article key={service.title} initial={{ opacity: 0, y: 26 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-70px" }} transition={{ duration: 0.55, delay: index * 0.06 }} className="group rounded-lg border border-white/10 bg-white/[0.04] p-6 transition hover:-translate-y-1 hover:border-brand-green/50 hover:bg-white/[0.07]">
                <Icon className="h-7 w-7 text-brand-green" />
                <h3 className="mt-8 text-xl font-semibold text-white">{service.title}</h3>
                <p className="mt-4 text-sm leading-6 text-white/[0.62]">{service.copy}</p>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export function ProjectCard({ project, index = 0 }: { project: (typeof projects)[number]; index?: number }) {
  return (
    <motion.article initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-70px" }} transition={{ duration: 0.6, delay: index * 0.08 }} className="group overflow-hidden rounded-lg bg-white shadow-[0_24px_70px_rgba(0,0,0,0.08)]">
      <Link href={`/project/${project.slug}`} className="block">
        <div className="relative h-64 overflow-hidden bg-brand-ink">
          <Image src={project.image} alt={`${project.title} portfolio visual`} fill sizes="(min-width: 1024px) 33vw, 100vw" className="object-cover transition duration-700 group-hover:scale-105" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/[0.78] via-black/10 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 p-5">
            <p className="text-sm font-medium text-white/[0.62]">{project.category}</p>
            <p className="mt-2 text-2xl font-semibold text-white">{project.result}</p>
          </div>
        </div>
        <div className="p-7">
          <h3 className="text-2xl font-semibold text-brand-ink">{project.title}</h3>
          <p className="mt-4 leading-7 text-black/[0.58]">{project.copy}</p>
          <div className="mt-6 flex flex-wrap gap-2">
            {project.tags.map((tag) => (
              <span key={tag} className="rounded-full bg-brand-dark/[0.08] px-3 py-1 text-xs font-semibold text-brand-dark">{tag}</span>
            ))}
          </div>
        </div>
      </Link>
    </motion.article>
  );
}

export function PortfolioSection() {
  const copy = useCopy();

  return (
    <section className="bg-brand-bone px-4 py-24 text-brand-ink sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionTitle title={copy.portfolioTitle} copy={copy.portfolioCopy} dark />
        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {projects.map((project, index) => <ProjectCard key={project.slug} project={project} index={index} />)}
        </div>
        <PortfolioSectionsGrid />
      </div>
    </section>
  );
}

export function PortfolioSectionsGrid() {
  const copy = useCopy();

  return (
    <div className="mt-20">
      <div className="max-w-2xl">
        <SectionLabel>{copy.sectionsLabel}</SectionLabel>
        <h3 className="text-balance text-3xl font-semibold leading-tight sm:text-5xl">{copy.sectionsTitle}</h3>
      </div>
      <div className="mt-10 grid gap-5 lg:grid-cols-2">
        {portfolioSections.map((section, index) => (
          <motion.article key={section.title} initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-70px" }} transition={{ duration: 0.58, delay: index * 0.05 }} className="grid overflow-hidden rounded-lg bg-white shadow-[0_22px_60px_rgba(0,0,0,0.07)] sm:grid-cols-[0.9fr_1.1fr]">
            <div className="grid min-h-72 auto-rows-fr grid-cols-2 gap-2 bg-brand-ink p-2">
              {section.images.length > 0 ? section.images.map((src, imageIndex) => (
                <div key={src} className={`relative overflow-hidden rounded-md ${section.images.length === 1 ? "col-span-2" : ""}`}>
                  <Image src={src} alt={`${section.title} extracted portfolio image ${imageIndex + 1}`} fill sizes="(min-width: 1024px) 25vw, 50vw" className="object-cover" />
                </div>
              )) : (
                <div className="col-span-2 grid place-items-center rounded-md border border-dashed border-brand-green/45 bg-brand-dark p-6 text-center">
                  <div>
                    <BarChart3 className="mx-auto h-10 w-10 text-brand-green" />
                    <p className="mt-4 text-sm font-semibold uppercase tracking-[0.18em] text-white/70">{copy.placeholder}</p>
                  </div>
                </div>
              )}
            </div>
            <div className="p-7">
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-green">{section.title}</p>
              <p className="mt-5 text-lg leading-8 text-black/[0.66]">{section.description}</p>
              <p className="mt-6 rounded-lg bg-brand-bone p-4 text-sm leading-6 text-black/[0.58]">{section.note}</p>
            </div>
          </motion.article>
        ))}
      </div>
    </div>
  );
}

export function TestimonialsSection() {
  const copy = useCopy();

  return (
    <section className="bg-black px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionTitle title={copy.testimonialsTitle} copy={copy.testimonialsCopy} />
        <div className="mt-14 grid gap-5 lg:grid-cols-3">
          {testimonials.map((item, index) => (
            <motion.figure key={item.name} initial={{ opacity: 0, y: 26 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-70px" }} transition={{ duration: 0.55, delay: index * 0.08 }} className="rounded-lg border border-white/10 bg-white/[0.04] p-7">
              <Quote className="h-8 w-8 text-brand-green" />
              <blockquote className="mt-8 text-lg leading-8 text-white/[0.78]">{item.quote}</blockquote>
              <figcaption className="mt-8 border-t border-white/10 pt-5">
                <p className="font-semibold text-white">{item.name}</p>
                <p className="mt-1 text-sm text-white/[0.48]">{item.role}</p>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}

export function ProcessSection() {
  const copy = useCopy();

  return (
    <section className="bg-white px-4 py-24 text-brand-ink sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionTitle title={copy.processTitle} copy={copy.processCopy} dark />
        <div className="mt-16 grid gap-4 md:grid-cols-2 lg:grid-cols-6">
          {process.map((step, index) => (
            <motion.div key={step} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-70px" }} transition={{ duration: 0.5, delay: index * 0.06 }} className="rounded-lg border border-black/10 p-5">
              <p className="text-sm font-semibold text-brand-green">0{index + 1}</p>
              <h3 className="mt-8 text-xl font-semibold">{step}</h3>
              <p className="mt-3 text-sm leading-6 text-black/[0.55]">
                {index === 0 && "Review the brand, audience, offer, content, and growth bottlenecks."}
                {index === 1 && "Define positioning, priorities, channels, and the highest-leverage creative route."}
                {index === 2 && "Create the visuals, messaging assets, and reusable campaign components."}
                {index === 3 && "Develop pages, systems, or ad structures with clean handoff-ready execution."}
                {index === 4 && "Publish with quality checks, tracking basics, and launch-ready creative."}
                {index === 5 && "Read the data, improve the creative, and compound what works."}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function ContactSection() {
  const copy = useCopy();
  const [status, setStatus] = useState("");
  const highlights = [
    { icon: Target, label: "Strategy" },
    { icon: TrendingUp, label: "Growth" },
    { icon: Bot, label: "AI" }
  ];

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const name = String(data.get("name") || "");
    const email = String(data.get("email") || "");
    const project = String(data.get("project") || "");
    const message = String(data.get("message") || "");
    const subject = encodeURIComponent(`TYMarketing project request from ${name}`);
    const body = encodeURIComponent(
      `Name: ${name}\nEmail: ${email}\nProject type: ${project}\n\nMessage:\n${message}`
    );

    window.location.href = `mailto:hello@tymarketing.ma?subject=${subject}&body=${body}`;
    setStatus(copy.contactForm.success);
  }

  return (
    <section className="noise-layer grid-bg relative bg-brand-dark px-4 py-24 sm:px-6 lg:px-8">
      <div className="relative mx-auto grid max-w-7xl items-center gap-10 lg:grid-cols-[1fr_0.8fr]">
        <div>
          <SectionLabel>{copy.nav.contact}</SectionLabel>
          <motion.h2 initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }} variants={fadeUp} transition={{ duration: 0.65 }} className="text-balance text-4xl font-semibold leading-tight text-white sm:text-6xl">
            {copy.contactTitle}
          </motion.h2>
          <motion.p initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }} variants={fadeUp} transition={{ duration: 0.65, delay: 0.08 }} className="mt-6 max-w-2xl text-lg leading-8 text-white/[0.65]">
            {copy.contactCopy}
          </motion.p>
        </div>
        <motion.div initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-80px" }} transition={{ duration: 0.65 }} className="rounded-lg border border-white/[0.12] bg-white p-7 text-brand-ink shadow-premium">
          <div className="grid gap-4">
            <a href="mailto:hello@tymarketing.ma" className="inline-flex items-center justify-between rounded-lg bg-brand-ink px-5 py-4 font-semibold text-white transition hover:bg-brand-green hover:text-brand-dark">
              hello@tymarketing.ma <ArrowRight className="h-5 w-5" />
            </a>
            <a href="https://www.instagram.com/tymarketing.ma/" target="_blank" rel="noreferrer" className="inline-flex items-center justify-between rounded-lg border border-black/10 px-5 py-4 font-semibold transition hover:border-brand-green hover:text-brand-dark">
              @tymarketing.ma <ArrowRight className="h-5 w-5" />
            </a>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {highlights.map(({ icon: Icon, label }) => (
              <div key={label} className="rounded-lg bg-brand-bone p-4">
                <Icon className="h-5 w-5 text-brand-green" />
                <p className="mt-4 text-sm font-semibold">{label}</p>
              </div>
            ))}
          </div>
          <form onSubmit={handleSubmit} className="mt-8 grid gap-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="grid gap-2 text-sm font-semibold">
                {copy.contactForm.name}
                <input required name="name" placeholder={copy.contactForm.namePlaceholder} className="rounded-lg border border-black/10 bg-brand-bone px-4 py-3 font-normal outline-none transition focus:border-brand-green" />
              </label>
              <label className="grid gap-2 text-sm font-semibold">
                {copy.contactForm.email}
                <input required type="email" name="email" placeholder={copy.contactForm.emailPlaceholder} className="rounded-lg border border-black/10 bg-brand-bone px-4 py-3 font-normal outline-none transition focus:border-brand-green" />
              </label>
            </div>
            <label className="grid gap-2 text-sm font-semibold">
              {copy.contactForm.project}
              <input name="project" placeholder={copy.contactForm.projectPlaceholder} className="rounded-lg border border-black/10 bg-brand-bone px-4 py-3 font-normal outline-none transition focus:border-brand-green" />
            </label>
            <label className="grid gap-2 text-sm font-semibold">
              {copy.contactForm.message}
              <textarea required name="message" rows={4} placeholder={copy.contactForm.messagePlaceholder} className="resize-none rounded-lg border border-black/10 bg-brand-bone px-4 py-3 font-normal outline-none transition focus:border-brand-green" />
            </label>
            <button type="submit" className="inline-flex items-center justify-center gap-2 rounded-lg bg-brand-green px-5 py-4 font-semibold text-brand-dark transition hover:bg-brand-ink hover:text-white">
              {copy.contactForm.submit} <Send className="h-4 w-4" />
            </button>
            {status ? <p className="text-sm font-medium text-brand-dark">{status}</p> : null}
          </form>
        </motion.div>
      </div>
    </section>
  );
}

export function ProjectDetail({ project }: { project: (typeof projects)[number] }) {
  return (
    <PageShell>
      <ProjectDetailContent project={project} />
    </PageShell>
  );
}

function ProjectDetailContent({ project }: { project: (typeof projects)[number] }) {
  const copy = useCopy();

  return (
    <>
      <InnerHero eyebrow={project.category} title={project.title} copy={project.copy} image={project.image} />
      <section className="bg-white px-4 py-24 text-brand-ink sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.75fr_1.25fr]">
          <div>
            <SectionLabel>{copy.caseStudy}</SectionLabel>
            <h2 className="text-balance text-4xl font-semibold leading-tight sm:text-5xl">{project.result}</h2>
            <div className="mt-7 flex flex-wrap gap-2">
              {project.tags.map((tag) => (
                <span key={tag} className="rounded-full bg-brand-dark/[0.08] px-3 py-1 text-xs font-semibold text-brand-dark">{tag}</span>
              ))}
            </div>
          </div>
          <div className="grid gap-8">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-green">{copy.challenge}</p>
              <p className="mt-4 text-lg leading-8 text-black/[0.64]">{project.challenge}</p>
            </div>
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-green">{copy.solution}</p>
              <p className="mt-4 text-lg leading-8 text-black/[0.64]">{project.solution}</p>
            </div>
          </div>
        </div>
      </section>
      <section className="bg-brand-bone px-4 py-24 text-brand-ink sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionTitle title={copy.visuals} copy={copy.visualsCopy} dark />
          <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {project.gallery.map((src, index) => (
              <motion.div key={src} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-70px" }} transition={{ duration: 0.55, delay: index * 0.05 }} className="relative h-72 overflow-hidden rounded-lg bg-brand-ink shadow-[0_22px_60px_rgba(0,0,0,0.1)]">
                <Image src={src} alt={`${project.title} gallery image ${index + 1}`} fill sizes="(min-width: 1024px) 33vw, 100vw" className="object-cover" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      <ContactSection />
    </>
  );
}

function FloatingActions() {
  return (
    <div className="fixed bottom-5 right-5 z-40 grid gap-3">
      <a
        href="https://wa.me/212724161573"
        target="_blank"
        rel="noreferrer"
        aria-label="Contact TYMarketing on WhatsApp"
        className="grid h-12 w-12 place-items-center rounded-full bg-brand-green text-brand-dark shadow-premium transition hover:-translate-y-1 hover:bg-white"
      >
        <MessageCircle className="h-5 w-5" />
      </a>
      <a
        href="https://www.instagram.com/tymarketing.ma/"
        target="_blank"
        rel="noreferrer"
        aria-label="Open TYMarketing Instagram"
        className="grid h-12 w-12 place-items-center rounded-full border border-white/10 bg-black/70 text-white shadow-premium backdrop-blur transition hover:-translate-y-1 hover:border-brand-green hover:text-brand-green"
      >
        <Instagram className="h-5 w-5" />
      </a>
    </div>
  );
}
