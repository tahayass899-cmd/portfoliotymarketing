import re
from pathlib import Path


text = Path("lib/portfolio-data.ts").read_text(encoding="utf-8")
paths = sorted(set(re.findall(r"/portfolio/[^\"']+", text)))
missing = [path for path in paths if not Path("public", path.lstrip("/")).exists()]

print(f"paths={len(paths)}")
print(f"missing={missing}")
