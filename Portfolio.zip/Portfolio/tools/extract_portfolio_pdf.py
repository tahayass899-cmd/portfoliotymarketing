from pathlib import Path

from pypdf import PdfReader


PDF_PATH = Path(r"C:\Users\Lenovo\Desktop\Taha yassine (portfolio)).pdf")
TEXT_OUT = Path("portfolio-extract/text.txt")
IMAGE_DIR = Path("public/portfolio")


def main() -> None:
    TEXT_OUT.parent.mkdir(parents=True, exist_ok=True)
    IMAGE_DIR.mkdir(parents=True, exist_ok=True)

    reader = PdfReader(str(PDF_PATH))
    lines = [f"Pages: {len(reader.pages)}"]
    image_count = 0

    for page_index, page in enumerate(reader.pages, start=1):
        lines.append("\n" + "=" * 24 + f" PAGE {page_index} " + "=" * 24)
        lines.append(page.extract_text() or "")

        for image_index, image in enumerate(page.images, start=1):
            image_count += 1
            suffix = Path(image.name).suffix or ".png"
            target = IMAGE_DIR / f"pdf-page-{page_index:02d}-image-{image_index:02d}{suffix}"
            target.write_bytes(image.data)

    TEXT_OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"pages={len(reader.pages)}")
    print(f"images={image_count}")
    print(TEXT_OUT.resolve())
    print(IMAGE_DIR.resolve())


if __name__ == "__main__":
    main()
