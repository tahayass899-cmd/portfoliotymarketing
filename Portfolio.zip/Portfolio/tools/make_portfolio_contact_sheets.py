from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


SRC = Path("public/portfolio")
OUT = Path("portfolio-extract")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    files = [p for p in sorted(SRC.iterdir()) if p.suffix.lower() in {".jpg", ".jpeg", ".png", ".jp2"} and p.stat().st_size > 500]
    font = ImageFont.load_default()
    cell_w, cell_h = 220, 190
    cols = 4

    for sheet_index, start in enumerate(range(0, len(files), cols * 4), start=1):
        group = files[start : start + cols * 4]
        rows = (len(group) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * cell_w, rows * cell_h), "#f6f7f2")
        draw = ImageDraw.Draw(sheet)

        for idx, path in enumerate(group):
            x = (idx % cols) * cell_w
            y = (idx // cols) * cell_h
            try:
                im = Image.open(path).convert("RGB")
                im.thumbnail((cell_w - 20, cell_h - 44))
                ox = x + (cell_w - im.width) // 2
                oy = y + 10
                sheet.paste(im, (ox, oy))
            except Exception as exc:
                draw.text((x + 10, y + 30), f"Unreadable\n{exc}", fill="#202d10", font=font)
            draw.text((x + 10, y + cell_h - 28), path.name[:32], fill="#202d10", font=font)

        sheet.save(OUT / f"contact-sheet-{sheet_index:02d}.jpg", quality=92)

    print(f"sheets={(len(files) + cols * 4 - 1) // (cols * 4)}")


if __name__ == "__main__":
    main()
