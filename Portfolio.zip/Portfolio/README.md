# TYMarketing Portfolio

Premium routed portfolio website for TYMarketing, the Digital Marketing and AI Strategy freelance studio of Taha Yassine Moussaoui.

## Tech Stack

- Next.js
- Tailwind CSS
- Framer Motion
- Lucide React

## Run Locally

```bash
npm install
npm run dev
```

Then open `http://localhost:3000`.

## Vercel Deployment

This project is prepared for Vercel with:

- `vercel.json`
- `.vercelignore`
- SEO metadata
- `robots.txt` via `app/robots.ts`
- `sitemap.xml` via `app/sitemap.ts`
- route loading animation via `app/loading.tsx`

Use these Vercel settings:

- Framework preset: `Next.js`
- Install command: `npm install`
- Build command: `npm run build`
- Output directory: `.next`
- Node.js version: `20.x`

Optional environment variable:

```text
NEXT_PUBLIC_SITE_URL=https://your-production-domain.com
```

If this is not set, the app falls back to `https://tymarketing.vercel.app` for metadata, sitemap, and robots URLs.

## Features

- Dark/light mode toggle
- English/French language toggle
- Loading animation
- Floating WhatsApp button
- Instagram links
- SEO metadata, sitemap, and robots
- Contact form with prefilled email handoff
- Animated statistics section

## Routes

- `/`
- `/about`
- `/services`
- `/portfolio`
- `/project/[slug]`
- `/contact`

## PDF Extraction

The source portfolio PDF was extracted into:

- `portfolio-extract/text.txt`
- `public/portfolio/`

The website case studies and portfolio section cards now use those extracted project names, services, descriptions, images, and placeholders.
