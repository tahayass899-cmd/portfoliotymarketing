import type { MetadataRoute } from "next";
import { projects } from "@/lib/portfolio-data";
import { siteUrl } from "@/lib/site-config";

export default function sitemap(): MetadataRoute.Sitemap {
  const routes = ["", "/about", "/services", "/portfolio", "/contact"];
  const projectRoutes = projects.map((project) => `/project/${project.slug}`);

  return [...routes, ...projectRoutes].map((route) => ({
    url: `${siteUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: "monthly",
    priority: route === "" ? 1 : 0.8
  }));
}
