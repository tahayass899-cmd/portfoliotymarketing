# TYMarketing Portfolio PDF Extraction

Source PDF: `C:/Users/Lenovo/Desktop/Taha yassine (portfolio)).pdf`

## Extracted Services

- Brand Identity Design
- Graphic Design
- Website Development
- Brand Strategy
- Advertising

## Extracted / Inferred Project Names

- DJMarket Mini Supermarket
- Dar Lalla
- Tres Jolie Tours
- Cooperative Azzal
- TaalibPass
- Taj Dental Clinic
- Brave Website Concept
- Ginyard International Co.

## Website Case Study Cards Created

- DJMarket Mini Supermarket: brand identity, storefront, packaging, advertising.
- Tres Jolie Tours: travel identity, stationery, billboard, campaign visuals.
- TaalibPass: student platform identity, cards, app-style previews, social posts.
- Dar Lalla: Moroccan food brand identity, packaging, stickers, storefront previews.
- Taj Dental Clinic: healthcare identity board and professional mockups.
- Brave Website Concept: premium landing-page / website development concept.

## Portfolio Sections Created

- Brand Identity Design: populated with extracted identity board images.
- Store Front Design: populated with extracted storefront images.
- Graphic Design: populated with extracted ad/poster/social images.
- Website Development: populated with extracted website preview images.
- Brand Strategy: placeholder added because the PDF lists the service but does not include a detailed case-study page.
- Advertising: populated with ad visuals and a placeholder for metrics/results.

## Extracted Assets

- Raw text: `portfolio-extract/text.txt`
- Contact sheets: `portfolio-extract/contact-sheet-01.jpg` through `portfolio-extract/contact-sheet-05.jpg`
- Images: `public/portfolio/`
