export const services = [
  {
    title: "Brand Identity Design",
    copy: "Premium identity systems with logos, colors, typography, social templates, and visual rules that stay consistent.",
    icon: "identity"
  },
  {
    title: "Graphic Design",
    copy: "Campaign visuals, carousels, launch assets, and daily content designed for clarity, recognition, and conversion.",
    icon: "design"
  },
  {
    title: "Website Development",
    copy: "Fast, responsive websites built around trust, clean messaging, and smooth buyer journeys.",
    icon: "web"
  },
  {
    title: "Brand Strategy",
    copy: "Positioning, offers, content pillars, audience research, and AI-assisted workflows for sharper execution.",
    icon: "strategy"
  },
  {
    title: "Advertising",
    copy: "Ad concepts, funnels, creative testing, and performance campaigns for brands that want measurable growth.",
    icon: "ads"
  }
] as const;

export const projects = [
  {
    slug: "djmarket-mini-supermarket",
    title: "DJMarket Mini Supermarket",
    category: "Brand Identity / Storefront / Advertising",
    result: "Full retail identity",
    copy: "A retail brand system across logo usage, storefront signage, packaging mockups, promotional visuals, and delivery campaign creatives.",
    image: "/portfolio/pdf-page-13-image-01.jpg",
    gallery: [
      "/portfolio/pdf-page-13-image-01.jpg",
      "/portfolio/pdf-page-15-image-01.jpg",
      "/portfolio/pdf-page-16-image-02.jpg",
      "/portfolio/pdf-page-19-image-02.jpg",
      "/portfolio/pdf-page-19-image-03.jpg"
    ],
    tags: ["Brand Identity", "Storefront", "Ad Design"],
    challenge: "Create a recognizable supermarket identity that works across in-store signage, packaging, delivery visuals, and promotional campaigns.",
    solution: "Built a cohesive red retail system with logo applications, storefront previews, packaged touchpoints, and campaign-ready advertising graphics."
  },
  {
    slug: "tres-jolie-tours",
    title: "Tres Jolie Tours",
    category: "Brand Identity / Travel Campaign",
    result: "Tourism brand kit",
    copy: "A travel identity with logo applications, stationery, outdoor billboard concepts, and visual assets built around premium discovery.",
    image: "/portfolio/pdf-page-12-image-02.jpg",
    gallery: [
      "/portfolio/pdf-page-12-image-02.jpg",
      "/portfolio/pdf-page-09-image-02.jpg",
      "/portfolio/pdf-page-09-image-03.jpg",
      "/portfolio/pdf-page-09-image-05.jpg",
      "/portfolio/pdf-page-19-image-04.jpg"
    ],
    tags: ["Logo System", "Stationery", "Billboard"],
    challenge: "Shape a travel brand that feels polished and immediately legible across physical and digital touchpoints.",
    solution: "Designed a complete identity presentation with stationery, signage, billboard concepts, and social-ready campaign visuals."
  },
  {
    slug: "taalibpass",
    title: "TaalibPass",
    category: "Brand Identity / Graphic Design",
    result: "Student platform assets",
    copy: "A Moroccan student-services platform visual direction with logo explorations, cards, app-style previews, and social posts.",
    image: "/portfolio/pdf-page-14-image-01.jpg",
    gallery: [
      "/portfolio/pdf-page-14-image-01.jpg",
      "/portfolio/pdf-page-11-image-01.jpg",
      "/portfolio/pdf-page-11-image-02.jpg",
      "/portfolio/pdf-page-20-image-01.jpg",
      "/portfolio/pdf-page-20-image-06.jpg"
    ],
    tags: ["Identity", "Social Posts", "Platform Design"],
    challenge: "Give an education platform enough visual structure to communicate trust, access, and usefulness to Moroccan students.",
    solution: "Created identity boards, card concepts, app-style visuals, and social posts that make the student offer easy to understand."
  },
  {
    slug: "dar-lalla",
    title: "Dar Lalla",
    category: "Brand Identity / Packaging",
    result: "Moroccan food brand",
    copy: "A bold visual identity with packaging, stickers, storefront previews, and warm Moroccan product presentation.",
    image: "/portfolio/pdf-page-08-image-01.jpg",
    gallery: [
      "/portfolio/pdf-page-08-image-01.jpg",
      "/portfolio/pdf-page-08-image-02.jpg",
      "/portfolio/pdf-page-08-image-03.jpg",
      "/portfolio/pdf-page-08-image-04.jpg",
      "/portfolio/pdf-page-08-image-05.jpg"
    ],
    tags: ["Packaging", "Logo", "Retail"],
    challenge: "Translate a Moroccan food brand into a warm, memorable system for packaging and physical brand applications.",
    solution: "Built a bright orange identity with stickers, food packaging, storefront previews, and cohesive presentation mockups."
  },
  {
    slug: "taj-dental-clinic",
    title: "Taj Dental Clinic",
    category: "Brand Identity / Healthcare",
    result: "Clinic identity board",
    copy: "A healthcare identity presentation with clinical blue visual language, branded touchpoints, and a professional service feel.",
    image: "/portfolio/pdf-page-13-image-03.jpg",
    gallery: [
      "/portfolio/pdf-page-13-image-03.jpg",
      "/portfolio/pdf-page-13-image-02.jpg",
      "/portfolio/pdf-page-03-image-01.jpg"
    ],
    tags: ["Healthcare", "Identity", "Mockups"],
    challenge: "Make a clinic identity feel professional, trustworthy, and adaptable across service touchpoints.",
    solution: "Presented a clinical visual board with blue brand assets, dental imagery, and practical identity mockups."
  },
  {
    slug: "brave-website-concept",
    title: "Brave Website Concept",
    category: "Website Development / UI Direction",
    result: "Landing page concept",
    copy: "A dark premium website concept with a strong hero, athletic visual direction, and conversion-focused landing structure.",
    image: "/portfolio/pdf-page-21-image-02.jpg",
    gallery: [
      "/portfolio/pdf-page-21-image-02.jpg",
      "/portfolio/pdf-page-22-image-01.jpg",
      "/portfolio/pdf-page-23-image-01.jpg"
    ],
    tags: ["Website", "UI Design", "Landing Page"],
    challenge: "Create a website direction with strong first-screen impact and a premium visual tone.",
    solution: "Designed dark hero concepts, clear navigation, and conversion-focused layout direction for a modern landing page."
  }
] as const;

export const portfolioSections = [
  {
    title: "Brand Identity Design",
    description: "Logo systems, colors, typography, stationery, packaging, mockups, and social-ready brand guidelines extracted from the PDF portfolio.",
    images: ["/portfolio/pdf-page-05-image-01.jpg", "/portfolio/pdf-page-12-image-01.jpg", "/portfolio/pdf-page-12-image-03.jpg"],
    note: "Includes DJMarket, Dar Lalla, Tres Jolie Tours, Cooperative Azzal, TaalibPass, Taj Dental Clinic, and related identity boards."
  },
  {
    title: "Store Front Design",
    description: "Retail signage and physical storefront concepts for brands that need their identity to work outside social media.",
    images: ["/portfolio/pdf-page-15-image-01.jpg", "/portfolio/pdf-page-16-image-02.jpg", "/portfolio/pdf-page-16-image-04.jpg"],
    note: "The PDF includes DJMarket storefront mockups and signage variations."
  },
  {
    title: "Graphic Design",
    description: "Advertising posters, product promotions, social posts, merch mockups, and campaign visuals for multiple brand categories.",
    images: ["/portfolio/pdf-page-18-image-01.jpg", "/portfolio/pdf-page-19-image-01.jpg", "/portfolio/pdf-page-20-image-01.jpg"],
    note: "Includes DJMarket promotions, TaalibPass posts, Tres Jolie visuals, and merch concepts."
  },
  {
    title: "Website Development",
    description: "Website and landing-page concepts with premium hero design, product positioning, and interface direction.",
    images: ["/portfolio/pdf-page-21-image-02.jpg", "/portfolio/pdf-page-23-image-01.jpg"],
    note: "The PDF shows website previews; final live URLs can be added as case-study links later."
  },
  {
    title: "Brand Strategy",
    description: "The PDF lists brand strategy as a core TYMarketing service; strategy content is represented as a placeholder until full case notes are supplied.",
    images: [],
    note: "Placeholder: add positioning, audience, offer, and launch strategy details when available."
  },
  {
    title: "Advertising",
    description: "The portfolio includes ad-style creative examples across retail, travel, and education brands, ready to expand into full campaign case studies.",
    images: ["/portfolio/pdf-page-19-image-02.jpg", "/portfolio/pdf-page-19-image-03.jpg"],
    note: "Placeholder: add performance metrics, channels, budget, and campaign results when available."
  }
] as const;

export const testimonials = [
  {
    quote: "Taha turned scattered ideas into a polished brand system. The content finally looks premium and the campaigns are easier to run.",
    name: "Nadia R.",
    role: "Clinic Founder"
  },
  {
    quote: "The strategy was clear, modern, and practical. We moved faster because every design decision had a business reason.",
    name: "Youssef B.",
    role: "E-commerce Owner"
  },
  {
    quote: "TYMarketing gave our launch the exact agency feel we wanted without losing the speed of working with a focused freelancer.",
    name: "Sara M.",
    role: "Consultant"
  }
] as const;

export const process = ["Audit", "Strategy", "Design", "Build", "Launch", "Optimize"] as const;
